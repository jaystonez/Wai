---
title: 你好, Noi
authors: [lencx]
---

🚀 用 AI 点亮您的世界 - 探索、扩展、赋能。

- [Noi：跨平台定制化浏览器，最得力 AI 助手](https://mp.weixin.qq.com/s/dAN7LOw7mH609HdAyEvXfg)
- [Noi：插件介绍](https://mp.weixin.qq.com/s/M6gO6MdK5obCvs2LIBZA3w)
