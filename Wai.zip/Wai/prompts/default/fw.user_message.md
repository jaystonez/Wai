~~~json
{
    "user": "{{message}}"
}
~~~