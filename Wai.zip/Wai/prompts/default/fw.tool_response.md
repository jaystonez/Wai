~~~json
{
    "response_from_tool": "{{tool_name}}",
    "data": {{tool_response}}
}
~~~